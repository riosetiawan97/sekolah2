<?php
<a href="<?php echo base_url().'assets/images/'.$data->galeri_gambar;?>" class="image-link2">
                                <img src="<?php echo base_url().'assets/images/'.$data->galeri_gambar;?>" class="all img-fluid" alt="#" />
                                </a>